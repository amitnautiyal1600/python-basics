jQuery(document).ready(function () {

    jQuery('#sms_form_btn').on('click', function (e) {
        e.preventDefault();
        jQuery('#result_data').html('');
        jQuery('#error_msg_frontend').html('');
        // jQuery('#error_msg_frontend').hide('');

        var mobile_number =  jQuery('#mobile_number').val();
        //jQuery('#loading_image').css('display', 'block');
        if(mobile_number == '') {
            jQuery('#error_msg_frontend').show();
            jQuery('#error_msg_frontend').html('** Please Enter Mobile No.');
            return true;
        }
 
        var filter = /^[0-9-+]+$/;
        if (!filter.test(mobile_number) || mobile_number.length != 10) {
            jQuery('#error_msg_frontend').show();
            jQuery('#error_msg_frontend').html('** Please Enter Correct 10 Digit Mobile No.');
            return true;
        } 

        jQuery.ajax({
            url: my_ajax_object.ajax_url,
            data: {
                'action': 'send_sms',
                'mobile_number': mobile_number,
            },
            type: 'POST',
            beforeSend: function (xhr) { 
                canBeLoaded = false;
                jQuery('#loading_image').show();
                jQuery('#mobile_number').prop("disabled", true);
                jQuery('#result_data').html('');
                jQuery('#error_msg_frontend').html('');
                jQuery('#error_msg_frontend').hide('');

            },
            success: function (response) {
                if (response) { 
                    if(response.status == 'success'){
                        jQuery('#mobile_number').val('');
                        $html = '<a download href="javascript:;" class="download_link">'+response.message+'</a>'
                        jQuery('#result_data').html($html);

                    } else {
                        jQuery('#error_msg_frontend').show();
                        jQuery('#error_msg_frontend').html(response.message);
                    } 
                }
            },
            complete: function () {
                jQuery('#loading_image').hide();
                jQuery('#mobile_number').prop("disabled", false);
            }
        });//End Ajax

    });//End btn click function


});//ebd document ready
