<?php

class Frontend
{
    use SmsView;

    public function init()
    {

        try { 
            $this->create_plugin_database_table();
            add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts_and_styles_function'));
            add_action( 'admin_enqueue_scripts',array($this, 'an_enqueue_custom_admin_style'));

            add_action( 'wp_ajax_send_sms', array($this,'send_sms') );
            add_action( 'wp_ajax_nopriv_send_sms', array($this,'send_sms') );

            add_action('admin_menu', array($this, 'setup_menus'));

            // Register our short-code
            add_shortcode('sms_form', array($this, 'sms_form_shortcode_handler'));
        } catch (Exception $ex) {
            print_r($ex);
        }

    }

    function create_plugin_database_table()
    {
        global $table_prefix, $wpdb;
        $table_prefix = $wpdb->base_prefix;

        /*
         * create table for SMS
         * */
        $tblname = 'sms_form_record';
        $wp_track_table = $table_prefix . $tblname;

        $sql = "CREATE TABLE IF NOT EXISTS `" . $wp_track_table . "` ( ";
        $sql .= "  `id`  int(11)   NOT NULL auto_increment, ";
        $sql .= "  `mobile`  varchar(255)   NOT NULL, ";
        $sql .= "  `sms_status`  varchar(255)   NOT NULL, ";
        $sql .= "  `sms_id`  varchar(255)   NOT NULL, ";
        $sql .= "  `sms_notes`  varchar(255)   NOT NULL, ";
        $sql .= "  `created_at`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
        $sql .= "  PRIMARY KEY `id` (`id`) ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ";
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        dbDelta($sql);

         /*
         * create table for SMS Setting
         * */
        $tblname = 'sms_setting';
        $wp_track_table = $table_prefix . $tblname;

        $sql = "CREATE TABLE IF NOT EXISTS `" . $wp_track_table . "` ( ";
        $sql .= "  `id`  int(11)   NOT NULL auto_increment, ";
        $sql .= "  `setting_key`  varchar(255)   NOT NULL, ";
        $sql .= "  `setting_value`  varchar(255)   NOT NULL, ";
        $sql .= "  `created_at`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, ";
        $sql .= "  PRIMARY KEY `id` (`id`) ";
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ";
        // require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        dbDelta($sql);

        $result = $wpdb->get_results("SELECT setting_value FROM $wp_track_table where setting_key = 'sms_api'");
        if (!$result) {  
            $insert_result = $wpdb->insert($wp_track_table, array(
                'setting_key' => 'sms_api',
                'setting_value' => 'http://roundsms.com/api/sendhttp.php',
                'created_at' => current_time('mysql')
            ));
        }

        $result = $wpdb->get_results("SELECT setting_value FROM $wp_track_table where setting_key = 'authkey'");
        if (!$result) {  
            $insert_result = $wpdb->insert($wp_track_table, array(
                'setting_key' => 'authkey',
                'setting_value' => 'ZTg5OTkyMTMxMmQ',
                'created_at' => current_time('mysql')
            ));
        }

        $result = $wpdb->get_results("SELECT setting_value FROM $wp_track_table where setting_key = 'sms_sender'");
        if (!$result) {  
            $insert_result = $wpdb->insert($wp_track_table, array(
                'setting_key' => 'sms_sender',
                'setting_value' => 'DGASTR',
                'created_at' => current_time('mysql')
            ));
        }
        
        $result = $wpdb->get_results("SELECT setting_value FROM $wp_track_table where setting_key = 'sms_type'");
        if (!$result) {  
            $insert_result = $wpdb->insert($wp_track_table, array(
                'setting_key' => 'sms_type',
                'setting_value' => '1',
                'created_at' => current_time('mysql')
            ));
        }
        
        $result = $wpdb->get_results("SELECT setting_value FROM $wp_track_table where setting_key = 'sms_route'");
        if (!$result) {  
            $insert_result = $wpdb->insert($wp_track_table, array(
                'setting_key' => 'sms_route',
                'setting_value' => '3',
                'created_at' => current_time('mysql')
            ));
        }
        
        $result = $wpdb->get_results("SELECT setting_value FROM $wp_track_table where setting_key = 'message'");
        if (!$result) {  
            $insert_result = $wpdb->insert($wp_track_table, array(
                'setting_key' => 'message',
                'setting_value' => 'Your message goes here.',
                'created_at' => current_time('mysql')
            ));
        }

    }

    public function enqueue_scripts_and_styles_function()
    {
        wp_enqueue_script('plugin-js',
            plugins_url('src/assets/js/plugin.js',
                AN_SMS_PLUGIN_BASE_FILE),
            ['jquery']);       

        wp_enqueue_style('plugin-style',
            plugins_url('src/assets/css/style.css', AN_SMS_PLUGIN_BASE_FILE),
            array(),
            AN_SMS_PLUGIN_VERSION, 'all');

        wp_enqueue_style('plugin-fa-icon',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css',
            array(),
            AN_SMS_PLUGIN_VERSION, 'all');

        wp_localize_script( 'plugin-js', 'my_ajax_object',  
            array( 'ajax_url' => admin_url( 'admin-ajax.php' )));

    }

    function an_enqueue_custom_admin_style() {
        wp_enqueue_script('plugin-js',
            plugins_url('src/assets/js/plugin.js',
                AN_SMS_PLUGIN_BASE_FILE),
            ['jquery']);

        wp_enqueue_style('plugin-style',
            plugins_url('src/assets/css/style.css', AN_SMS_PLUGIN_BASE_FILE),
            array(),
            AN_SMS_PLUGIN_VERSION, 'all');
    }

    public function sms_form_shortcode_handler()
    {
        ob_start();
        $data = [];
        global $wpdb;
        $table_prefix = $wpdb->base_prefix;
        $tblname = 'sms_form_record';
        $table_name = $table_prefix . $tblname;
        $query = "SELECT * from $table_name";
        $result = $wpdb->get_results($query);
        if (!empty($result)) {
            $data = $result;
        }
        $this->load_view('Frontend', 'sms-form', $data);
        return ob_get_clean();
    }

    public function setup_menus()
    { 
        add_menu_page(
            'SMS Records | Add Or Edit Students Record',//title Of plugin
            'SMS Records',//name of plugin
            'manage_options',
            'sms-form', // code name 9 unique id to add submenu)
            array(new SMS_LIST(), 'sms_render_list_page'),// Function Name To show Content
            AN_SMS_PLUGIN_URL . '/src/assets/icon.png',
            9
        );


        add_submenu_page(
            'sms-form',
            'SMS Setting | Add Or Edit SMS Setting',//title Of plugin
            'SMS Setting',//name of plugin
            'manage_options',
            'sms-setting', // code name 9 unique id to add submenu)
            array(new SMS_LIST(), 'sms_render_setting_page'),// Function Name To show Content
            AN_SMS_PLUGIN_URL . '/src/assets/icon.png',
            9
        );
    }

    public function validate_data(){
        $this->errors = [];
        if (isset($_POST['submit'])) {
            if(!isset($_POST['market_id']) || $_POST['market_id'] == ''){
                $this->errors['market_id'] = "Select the value from search";
            }
        }
    }

    public function send_sms() {

        global $wpdb;
        
        $mobile_number = $_POST['mobile_number'];

        $table_name = $wpdb->base_prefix . "sms_setting";
        $result = $wpdb->get_results("SELECT * FROM $table_name");
        $data = array();
        foreach ($result as $key => $value) { 
           $data[$value->setting_key] = $value->setting_value;
        }
        // print_r($data);die;
        $sms_api = $data['sms_api'];
        $authkey = $data['authkey'];
        $sender_id = $data['sms_sender'];
        $type = $data['sms_type'];
        $route = $data['sms_route'];
        $message = $data['message'];
        // $url = "http://roundsms.com/api/sendhttp.php?authkey=ZTg5OTkyMTMxMmQ&mobiles=Mobile1&message=Your Message&sender=Sender Id&type=type&route=route";   
        $url = "$sms_api?authkey=$authkey&mobiles=$mobile_number&message=$message&sender=$sender_id&type=$type&route=$route";
        $ch = curl_init();   
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
        curl_setopt($ch, CURLOPT_URL, $url);   
        $res = curl_exec($ch); 
        if(!$res){
            $result_data = array(
                'status'=> 'fail',
                'message'=> 'Please Contact to Administrator!!',
                );
                wp_send_json($result_data);
                wp_die();
        }
        $result = json_decode($res);
        if(!$result->error){ 
            $sms_status = 'Success';
            $sms_id = $result->msg_id[0];
            $sms_notes = 'Submitted to sms portal';
        }else{ 
            $sms_status = 'Failed';
            $sms_id = 0;
            $sms_notes = $result->error;
        }
 
        $table_name = $wpdb->base_prefix . "sms_form_record"; 
        $insert_result = $wpdb->insert($table_name, array('mobile' => $mobile_number, 'sms_status' => $sms_status, 'sms_id' => $sms_id, 'sms_notes' => $sms_notes, 'created_at' => current_time('mysql')));
  
        if(!$result->error){ 
            $result_data = array(
            'status'=> 'success',
            'message'=> 'sms sent successfully',
            );
        } else {
            $result_data = array(
            'status'=> 'fail',
            'message'=> 'Try Again!!',
            );
        }        
        wp_send_json($result_data);
        wp_die();
    }

}
