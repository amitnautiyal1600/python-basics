<?php

if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}


class SMS_LIST extends \WP_List_Table
{

    function __construct()
    {
        global $status, $page;
        //Set parent defaults
        parent::__construct(array(
            'singular' => 'SMS',     //singular name of the listed records
            'plural' => 'SMSs',    //plural name of the listed records
            'ajax' => false        //does this table support ajax?
        ));

    }

    function column_default($item, $column_name)
    {
        switch ($column_name) {
            case 'sms_status':
            case 'sent_on':
            case 'sms_notes':
            case 'sent_on':
                return $item[$column_name];
            default:
                return print_r($item, true); //Show the whole array for troubleshooting purposes
        }
    }

    function column_title($item)
    {
        //Build row actions
        $actions = array(
            // 'edit' => sprintf('<a href="?page=%s&action=%s&id=%s">Edit</a>', $_REQUEST['page'], 'edit', $item['ID']),
            'delete' => sprintf('<a href="?page=%s&action=%s&id=%s">Delete</a>', $_REQUEST['page'], 'delete', $item['ID']),
        );

        //Return the title contents
        return sprintf('%1$s <span style="color:silver">(id:%2$s)</span>%3$s',
            /*$1%s*/
            $item['title'],
            /*$2%s*/
            $item['ID'],
            /*$3%s*/
            $this->row_actions($actions)
        );
    }

    function column_cb($item)
    {
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/
            $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
            /*$2%s*/
            $item['ID']                //The value of the checkbox should be the record's id
        );
    }

    function get_columns()
    {
        $columns = array(
            'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
            'title' => 'Mobile Number',
            'sms_status' => 'SMS Status',
            'sms_notes' => 'SMS Notes',
            'sent_on' => 'Sent Date'
        );
        return $columns;
    }


    function get_sortable_columns()
    {
        $sortable_columns = array(
            'title' => array('title', false),     //true means it's already sorted
            'sms_status' => array('sms_status', false),     //true means it's already sorted
            'sms_notes' => array('sms_notes', false),     //true means it's already sorted
            'sent_on' => array('sent_on', false),     //true means it's already sorted
        );
        return $sortable_columns;
    }


    function get_bulk_actions()
    {
        $actions = array(
            'delete' => 'Delete'
        );
        return $actions;
    }

    function delete_bulk_record()
    {
        global $wpdb;
        $id ='';
        if(isset($_GET['id'])){
            $id = absint($_GET['id']);
        }
        $table_name = $wpdb->base_prefix . "sms_form_record";

        $delete_result = $wpdb->delete(
            "{$wpdb->prefix}sms_form_record",
            ['id' => $id],
            ['%d']
        );
        if ($delete_result) {
            echo "<div class='success_msg'>Record has been deleted successfully!</div>";
        } else {
            $loc='';
            if(isset($_GET['sms'])) {
                $loc = $_GET['sms'];
            }
            if ($loc) {
                foreach ($loc as $id) {
                    $delete_result = $wpdb->delete(
                        "{$wpdb->prefix}sms_form_record",
                        ['id' => $id],
                        ['%d']
                    );                    
                }
                if($delete_result){
                    echo "<div class='success_msg'>All selected records has been deleted successfully!</div>";
                }
            }
        }
    }

    function process_bulk_action()
    {
        //Detect when a bulk action is being triggered...
        if ('delete' === $this->current_action()) {
                self::delete_bulk_record();
        }

    }

    function prepare_items()
    {
        global $wpdb;
        $table_name = $wpdb->base_prefix . "sms_form_record";
        $this->process_bulk_action();
        $result = $wpdb->get_results("SELECT * FROM $table_name");
        if ($result) {
            $list = array();
            foreach ($result as $results) {
                $list[] = array(
                    "ID" => $results->id,
                    "title" => $results->mobile,
                    "sms_status" => $results->sms_status,
                    "sms_notes" => $results->sms_notes,
                    "sent_on" => $results->created_at,
                );

            }
            $per_page = 8;
            $columns = $this->get_columns();
            $hidden = array();
            $sortable = $this->get_sortable_columns();
            $this->_column_headers = array($columns, $hidden, $sortable);

            $data = $list;
            $current_page = $this->get_pagenum();
            $total_items = count($data);
            $data = array_slice($data, (($current_page - 1) * $per_page), $per_page);
            $this->items = $data;
            $this->set_pagination_args(array(
                'total_items' => $total_items,                  //WE have to calculate the total number of items
                'per_page' => $per_page,                     //WE have to determine how many items to show on a page
                'total_pages' => ceil($total_items / $per_page)   //WE have to calculate the total number of pages
            ));
        }
    }

    function sms_render_setting_page()
    {   
        $this->save_data();  
        global $wpdb;
        $table_name = $wpdb->base_prefix . "sms_setting";
        $result = $wpdb->get_results("SELECT * FROM $table_name");
        $data = array();
        foreach ($result as $key => $value) { 
           $data[$value->setting_key] = $value->setting_value;
        }  

        if (isset($_GET['action'])) {
            $action = $_GET['action'];
        }

        if (isset($_GET['id'])) {
            $selID = $_GET['id'];
        }

        ?>
        <div class="wrap">
            <div class="wrap" style="text-align: left;margin-top: 15px;">
                <?php
                if ($action == 'edit') {
                    echo '<h2 class="page_title">Edit SMS Setting</h2>';

                } else {
                    echo '<h2 class="page_title">SMS Setting</h2>';
                } 
                 
                ?> 
                <div class="ui-widget">
                    <form action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <table class="registration_table">
                                <tr>
                                    <td><label for="sms_api">SMS API : </label></td>
                                    <td><input type="text" name="sms_api" class="sms_api" id="sms_api" placeholder="Enter SMS API" value="<?php echo $data['sms_api']; ?>" required/></td>
                                </tr>
                                <tr>
                                    <td><label for="authkey">AUTH KEY : </label></td>
                                    <td><input type="text" name="authkey" class="authkey" id="authkey" placeholder="Enter SMS API" value="<?php echo $data['authkey']; ?>" required/></td>
                                </tr>
                                <tr>
                                    <td><label for="sms_sender">SMS SENDER ID : </label></td>
                                    <td><input type="text" name="sms_sender" class="sms_sender" id="sms_sender" placeholder="Enter SMS API" value="<?php echo $data['sms_sender']; ?>" required/></td>
                                </tr>
                                <tr>
                                    <td><label for="sms_type">SMS TYPE : </label></td>
                                    <td>
                                        <select id="sms_type" class="sms_type" name="sms_type"  required autofocus> 
                                            <?php 
                                                $class_selected = '';
                                                if ($data['sms_type'] == '1') {
                                                    $class_selected =  'selected';
                                                }
                                                echo '<option value="1" '.$class_selected.'>Normal</option>';
                                             
                                                $class_selected = '';
                                                if ($data['sms_type'] == '2') {
                                                    $class_selected =  'selected';
                                                }
                                                echo '<option value="2" '.$class_selected.'>Unicode</option>';
                                            ?>
                                        </select>
                                </tr>
                                <tr>
                                    <td><label for="sms_route">SMS ROUTE : </label></td>
                                    <td>
                                        <select id="sms_route" class="sms_route" name="sms_route"  required autofocus> 
                                            <?php 
                                                $class_selected = '';
                                                if ($data['sms_route'] == '1') {
                                                    $class_selected =  'selected';
                                                }
                                                echo '<option value="1" '.$class_selected.'>Promotional</option>';
                                             
                                                $class_selected = '';
                                                if ($data['sms_route'] == '2') {
                                                    $class_selected =  'selected';
                                                }
                                                echo '<option value="2" '.$class_selected.'>Transactional</option>';
                                             
                                                $class_selected = '';
                                                if ($data['sms_route'] == '3') {
                                                    $class_selected =  'selected';
                                                }
                                                echo '<option value="3" '.$class_selected.'>Promo SenderID</option>';
                                            ?>
                                        </select>
                                </tr>
                                <tr>
                                    <td><label for="message">SMS MESSAGE : </label></td>
                                    <td><textarea type="text" name="message" class="message" id="message" placeholder="Enter SMS API" rows='7' required><?php echo $data['message']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td colspan="2" align="right"> 
                                        <button type="submit" name="update_sms_setting" class="submit_button">Update Record</button>
                                    </td>
                                </tr>
                            </table>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    function sms_render_list_page()
    {     
        $this->prepare_items(); 
        ?>
        <div class="wrap"> 
            <!--Show location Data in tabular form-->

            <div id="icon-users" class="icon32"><br/></div>
            <h2 class="page_title">All SMS Record</h2>
            <form id="movies-filter" method="get">
                <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>"/>
                <?php $this->display() ?>
            </form>
        </div>
        <?php
    }

    public function save_data()
    {
        if(isset($_POST['update_sms_setting'])) { 
            global $wpdb;           
            $table_name = $wpdb->base_prefix . "sms_setting";
            $sms_api = $_POST['sms_api'];
            $authkey = $_POST['authkey'];
            $sms_sender = $_POST['sms_sender'];
            $sms_type = $_POST['sms_type'];  
            $sms_route = $_POST['sms_route'];  
            $message = $_POST['message'];  
                
            $update_result = $wpdb->update(
                $table_name,
                array(
                    'setting_value' => $sms_api, 
                    'created_at' => current_time('mysql')
                    ),
                array('setting_key' => 'sms_api')
            ); 
            
            $update_result = $wpdb->update(
                $table_name,
                array(
                    'setting_value' => $authkey, 
                    'created_at' => current_time('mysql')
                    ),
                array('setting_key' => 'authkey')
            );
            
            $update_result = $wpdb->update(
                $table_name,
                array(
                    'setting_value' => $sms_sender, 
                    'created_at' => current_time('mysql')
                    ),
                array('setting_key' => 'sms_sender')
            );
            
            $update_result = $wpdb->update(
                $table_name,
                array(
                    'setting_value' => $sms_type, 
                    'created_at' => current_time('mysql')
                    ),
                array('setting_key' => 'sms_type')
            );
            
            $update_result = $wpdb->update(
                $table_name,
                array(
                    'setting_value' => $sms_route, 
                    'created_at' => current_time('mysql')
                    ),
                array('setting_key' => 'sms_route')
            );
            
            $update_result = $wpdb->update(
                $table_name,
                array(
                    'setting_value' => $message, 
                    'created_at' => current_time('mysql')
                    ),
                array('setting_key' => 'message')
            );

            if ($update_result) {
                echo '<div class="success_msg">Record Updated Successfully</div>';
            } else {
                echo '<div class="error_msg">Some Problem Occurred Please Try Again..</div>';
            }
        } 

        else {
            return 0;
        }
    } //End save data

        

}
