 

<form class="form-inline" name="sms_form_frontent" method="post" action="" id="sms_form_frontent"> 
  <input type="tel" id="mobile_number" placeholder="Contact No*" name="mobile_number" class='fusion-form-input' required> 
  <button type="submit" name="sms_form_btn" id="sms_form_btn" class='fusion-button button-flat fusion-button-default-size button-default fusion-button-default button-4 fusion-button-span-yes  form-form-submit button-default'>Submit</button>
  <div id="loding_image_div">
	    <img id="loading_image" src="<?php echo AN_SMS_PLUGIN_URL . '/src/assets/load.gif'?>" alt="Loading..."  style="display: none;" />
	</div>
</form> 
<div id="error_msg_frontend" class="error_msg_frontend" style="margin-left: 5px; "></div>
<div id="result_data" class="result_data" style="margin-left: 5px; "></div>
