<?php
if (!defined('ABSPATH')) {
    exit;
}

trait SmsView
{
    final function load_view($view_type, $view, $data = [])
    {
        extract($data);
        include AN_SMS_PLUGIN_DIR_PATH . 'src/views/' . $view_type . '/' . $view . '.php';
    }
}
