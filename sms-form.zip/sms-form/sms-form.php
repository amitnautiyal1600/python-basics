<?php
/*
  Plugin Name: SMS Form
  Plugin URI: https://www.facebook.com/amitnautiyal1600
  Description: Plugin to print form and send sms to user. Use shortocode <code>[sms_form]</code> .
  Version: 1.0.0
  Author: Amit Nautiyal
  Author URI: https://www.facebook.com/amitnautiyal1600
  Text Domain: an-sms-form
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
// Declare some global constants
define('AN_SMS_PLUGIN_VERSION', '1.1');
define('AN_SMS_PLUGIN_URL', plugins_url('/', __FILE__));
define('AN_SMS_PLUGIN_BASE_FILE', basename(dirname(__FILE__)) . '/sms-form.php');
define('AN_SMS_PLUGIN_BASE_NAME', plugin_basename(__FILE__));
define('AN_SMS_PLUGIN_UPLOAD_DIR', dirname(__FILE__));
define('AN_SMS_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__)); //use for include files to other files

require 'autoload.php';

(new Frontend())->init();
